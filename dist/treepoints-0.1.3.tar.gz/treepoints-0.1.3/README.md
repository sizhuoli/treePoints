# treePoints

A python package to build a tree database from remote sensing data.

## Installation

To install the package, follow instructions below.

### Step 1: Create a Specific Conda Environment

1. First, ensure that Conda is installed on your system.
2. Download the required conda environment file `environment.yml` from this GitHub [repository](https://github.com/sizhuoli/treePoints).
3. Create the Conda environment using the `environment.yml` file:

```bash
conda env create -f environment.yml
```

### Step 2: Activate the Conda Environment

After creating the Conda environment, activate it using the following command:

```bash
conda activate tf2151full_treepoints
```

### Step 3: Install the Package

#### Option 1: Install the Package from PyPI

* ( install the package directly, see deployment structure in test_example/ )

```
pip install treePoints
# pip install -i https://test.pypi.org/simple/ treepoints
```

#### Option 2: Install the Package from a cloned [repository](https://github.com/sizhuoli/treePoints):

* ( clone to run demo test examples )

```bash
git clone https://github.com/sizhuoli/treePoints.git
cd treePoints
pip install .
```


## Step 4: Demo Usage

See [repository](https://github.com/sizhuoli/treePoints).

```bash
python test_example/demo_predict.py
```

Set configs in test_example/config/hyperps.yaml